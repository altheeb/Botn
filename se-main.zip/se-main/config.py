from os import getenv
from dotenv import load_dotenv

load_dotenv()
que = {}
admins = {}

API_ID = int(getenv("API_ID", "8140181"))
API_HASH = getenv("API_HASH", "f0a3b2f0ceba543320aedeceb380e11d")
BOT_TOKEN = getenv("BOT_TOKEN","5627527973:AAGOOoQeVp8lKwzwIZhKglgJqrTA_2aOWqA")
BOT_NAME = getenv("BOT_NAME","𝐅 𝐁 𝐈🇸🇦ميوزك")
BOT_USERNAME = getenv("BOT_USERNAME", "FBIX1BOT")
OWNER_USERNAME = getenv("OWNER_USERNAME", "AILSSSSS")
SUPPORT_GROUP = getenv("SUPPORT_GROUP", "FBlX7")
DURATION_LIMIT = int(getenv("DURATION_LIMIT", "90"))
START_IMG = getenv("START_IMG", "https://telegra.ph/file/3e5f52df338796a7b6379.jpg")
PING_IMG = getenv("PING_IMG", "https://telegra.ph/file/3e5f52df338796a7b6379.jpg")
SESSION_NAME = getenv("SESSION_NAME", "--BAAKoD4vqG9MhnqFrbheH80us1If5tggGxHx17oJiXhqgjFPcyck_s9swrq9wvl0OLadTaTAgxyD-i3MXTl6wlqnXi2ks8ppjh-FIl9cNyT-JPjslP6xg3YTisfYRV3HCLPzF-OFfbDP480ZVus6_vz89G9dQAGP7BmedoqL37QPQP9OtewJEVpOqviaz6iaPoFD2tHWxuXLhnlvuB4CERhgXtLyQ5az3uzYsgWDKo1aarRUj10vTYbapQaTXCeSgC2R7q1XtixOQY5XeaJJvvOJMuos67SsHhjya-jyBGzEigC7V3C3cZuJrdGnkjZNyzyHxbL7rewqHxH_bGZL2BGSAAAAAHlsyK8A")
COMMAND_PREFIXES = list(getenv("COMMAND_PREFIXES", "").split())
PMPERMIT = getenv("PMPERMIT", "ENABLE")
SUDO_USERS = list(map(int, getenv("SUDO_USERS", "846074155").split()))+ [5490392130]